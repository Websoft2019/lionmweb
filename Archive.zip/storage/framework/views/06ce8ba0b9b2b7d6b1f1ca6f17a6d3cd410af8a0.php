<?php $__env->startSection('css'); ?>
<style type="text/css">

#newsHeadlines {
	padding: 10px;
	border-left:#1c4f9c 4px solid;
	
}
#newsHeadlines ul {
    list-style: none;
    padding: 0;
    margin: 0;
    
}

#newsHeadlines .head {
	font-weight:bold;
	font-size:14px;
	color:#1c4f9c;
}

#newsHeadlines a {
	color:#444;
	font-size:15px;
	text-decoration:none;
}

.news_post {
	color:#F90;
}

.accordionWrapper{display:inline-block; background-color:#fff; overflow:hidden; margin-bottom:20px;}
.accordionWrapper img{vertical-align:top; border:0; margin:0; padding:0}
.accordionWrapper div{display:inline; float:left; margin:auto;}
.accordionWrapper div.title{cursor:pointer;}
.accordionWrapper div.content{display:none;}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="main-slider clearfix">
    <div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": 1, "loop": true,
        "effect": "fade",
        "pagination": {
        "el": "#main-slider-pagination",
        "type": "bullets",
        "clickable": true
        },
        "navigation": {
        "nextEl": "#main-slider__swiper-button-next",
        "prevEl": "#main-slider__swiper-button-prev"
        },
        "autoplay": {
        "delay": 5000
        }}'>
        <div class="swiper-wrapper">

            <div class="swiper-slide">
                <div class="image-layer"
                    style="background-image: url(<?php echo e(asset('site/assets/images/backgrounds/main-slider-1-1.png')); ?>);"></div>
                <!-- /.image-layer -->

                <div class="main-slider-shape-1"
                    style="background-image: url(<?php echo e(asset('site/assets/images/shapes/main-slider-shape-1.jpg')); ?>);"></div>
                <div class="main-slider-shape-2 float-bob-x">
                    <img src="<?php echo e(asset('site/assets/images/shapes/main-slider-shape-2.png')); ?>" alt="">
                </div>

                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-8">
                            <div class="main-slider__content">
                                <p class="main-slider__sub-title">We Serve</p>
                                <h2 class="main-slider__title">Lend a Helping Hand to Those in Need</h2>
                                <div class="main-slider__btn-box">
                                    <a href="" class="thm-btn main-slider__btn"> Discover more</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="swiper-slide">
                <div class="image-layer"
                    style="background-image: url(<?php echo e(asset('site/assets/images/backgrounds/main-slider-1-2.png')); ?>);"></div>
                <!-- /.image-layer -->

                <div class="main-slider-shape-1"
                    style="background-image: url(<?php echo e(asset('site/assets/images/shapes/main-slider-shape-1.jpg')); ?>);"></div>
                <div class="main-slider-shape-2 float-bob-x">
                    <img src="<?php echo e(asset('site/assets/images/shapes/main-slider-shape-2.png')); ?>" alt="">
                </div>

                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-8">
                            <div class="main-slider__content">
                                <p class="main-slider__sub-title">Always donate for childrens</p>
                                <h2 class="main-slider__title">Lend a Helping Hand to Those in Need</h2>
                                <div class="main-slider__btn-box">
                                    <a href="" class="thm-btn main-slider__btn"> Discover more</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="swiper-slide">
                <div class="image-layer"
                    style="background-image: url(<?php echo e(asset('site/assets/images/backgrounds/main-slider-1-3.png')); ?>);"></div>
                <!-- /.image-layer -->

                <div class="main-slider-shape-1"
                    style="background-image: url(<?php echo e(asset('site/assets/images/shapes/main-slider-shape-1.jpg')); ?>);"></div>
                <div class="main-slider-shape-2 float-bob-x">
                    <img src="<?php echo e(asset('site/assets/images/shapes/main-slider-shape-2.png')); ?>" alt="">
                </div>

                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-8">
                            <div class="main-slider__content">
                                <p class="main-slider__sub-title">We Serve</p>
                                <h2 class="main-slider__title">Lend a Helping Hand to Those in Need</h2>
                                <div class="main-slider__btn-box">
                                    <a href="" class="thm-btn main-slider__btn"> Discover more</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- If we need navigation buttons -->
        <div class="main-slider__nav">
            <div class="swiper-button-prev" id="main-slider__swiper-button-next">
                <i class="icon-left-arrow"></i>
            </div>
            <div class="swiper-button-next" id="main-slider__swiper-button-prev">
                <i class="icon-right-arrow"></i>
            </div>
        </div>

    </div>
</section>
<?php if($notices->count()): ?>
<section class="noticbox" style="margin-bottom: 10px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12 notice-list">
                <div id="newsHeadlines">
                    <div>
                        <h5>Latest Notices</h5>
                    <ul id='headlines'>
                        <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href=" <?php echo e(route('getNoticeDetail', $notice->id)); ?> ">
                                <?php echo e($notice->created_at->format('d M, Y')); ?> ____
                                : <?php echo e($notice->title); ?>

                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    </div>
	                
                    <p style="text-align: right;"><a href=""><u> View all Notices </u></a></p>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<section class="about-one">
    <div class="about-one__shape-box-1">
        <div class="about-one__shape-1"
            style="background-image: url(<?php echo e(asset('site/assets/images/shapes/about-one-shape-1.png')); ?>);"></div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-6">
                <div class="about-one__left">
                    <div class="about-one__img-box wow slideInLeft" data-wow-delay="100ms"
                        data-wow-duration="2500ms">
                        <div class="about-one__img">
                            <img src="<?php echo e(asset('site/assets/images/governer-24-25.png')); ?>" alt="">
                        </div>
                        <div class="about-one__img-border"></div>
                        <div class="about-one__curved-circle-box">
                            <div class="curved-circle">
                                <span class="curved-circle--item">
                                    Lions Clubs International - District 325 J, Nepal -
                                </span>
                            </div><!-- /.curved-circle -->
                            <div class="about-one__curved-circle-icon">
                                <img src="<?php echo e(asset('site/assets/images/logo-23-24.png')); ?>" alt="" style="width:100px">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="about-one__right">
                    <div class="section-title text-left">
                        <h5>Welcome to Lions District 325 J, Nepal</h5>
                        <h6 class="" style="color:#1c4f9c;">"Brave Enough to Start"</h6>
                    </div>
                    <p class="about-one__text">
                        “साहसिक शुरुवात” लायन्स इन्टरनेशनल डिष्ट्रिक्ट ३२५ जे नेपालको लायन वर्ष २०२३/०२४ को नारा हो । जसले हरेक लायन सदस्यहरुलाई सेवा, नेतृत्व र भातृत्व विकासका लागि नयाँ कुरा शुरु गर्न र उनीहरुसँग भएको साहस लाई उजागर गर्न प्रोत्साहन मिल्दछ ।
                    </p>
                    <p>
                        डिष्ट्रिक्टको आह्वान साकार पार्न हाम्रा सदस्यहरुमा अदम्य साहस तथा भविष्यको लागि जुनसुकै चुनौती र अप्ठ्याराहरुको सामना गर्ने क्षमतामा विकास हुने छ । सेवा गर्ने क्रममा आई पर्ने विभिन्न अवरोधहरुलाई परास्त गर्दै हाम्रा सेवा कार्यलाई शिखरमा पुर्याई समाजमा लायन्स प्रति सकारात्मक छाप छोड्न सफलता मिल्नेछ । साहसिक नेताहरुले आफ्ना सदस्यहरुलाई रचनात्मक आलोचना प्रति ग्रहणशिल हुन र नयाँ विचार र दृष्टिकोण निर्माण गर्दै साझा लक्ष प्रप्तिका लागि साहसिक शुरुवात गर्ने कुरामा पूर्ण विश्वस्त छौ।
                    </p>
                        <!-- <div class="about-one__fund">
                        <p class="about-one__fund-text">Helped fund <span>24,537</span> Projects in
                            <span>24</span> Countries, Benefiting over <br> <span>8.2</span> Million people.</p>
                    </div> -->
                    <br />
                    <ul class="list-unstyled about-one__points">
                        <li>
                            <div class="icon">
                                <span class="icon-volunteer"></span>
                            </div>
                            <div class="text">
                                <h5><a href="">Join our team</a></h5>
                                <p>Join with us as a new club. </p>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-solidarity"></span>
                            </div>
                            <div class="text">
                                <h5><a href="">Start donating</a></h5>
                                <p>Helping people with us</p>
                            </div>
                        </li>
                    </ul>
                    <a href="" class="thm-btn about-one__btn">Discover More</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="causes-one">
    <div class="container">
        <div class="section-title text-center">
            <span class="section-title__tagline">Social Welfare</span>
            <h2 class="section-title__title">Districts <br> Focused Programs</h2>
        </div>
        <div class="row">
            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                <div class="causes-one__single">
                    <div class="causes-one__img">
                        <img src="<?php echo e(asset('site/uploads/program/'.$program->photo)); ?>" alt="">
                        <div class="causes-one__cat">
                            <p>Focused Programs</p>
                        </div>
                    </div>
                    <div class="causes-one__content">
                        <h3 class="causes-one__title"><a href="<?php echo e(route('getProgramDetail', $program->slug)); ?>"><?php echo e($program->title); ?></a>
                        </h3>
                        <div class="col-md-12" style="text-align:center; margin-top: 10px;">
                            <a href="<?php echo e(route('getProgramDetail', $program->slug)); ?>" class="thm-btn">Read Detail</a>
                        </div>
                    </div>
                   
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- <section class="counter-one">
    <div class="container">
        <div class="counter-one__inner">
            <div class="counter-one-bg" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
                style="background-image: url(<?php echo e(asset('site/assets/images/backgrounds/counter-one-bg.jpg')); ?>);"></div>
            <ul class="list-unstyled counter-one__list">
                <li class="counter-one__single">
                    <div class="counter-one__count-box">
                        <h3 class="odometer" data-count="70">00</h3>
                        <span class="counter-one__letter">m</span>
                    </div>
                    <p class="counter-one__text">Total donation</p>
                </li>
                <li class="counter-one__single">
                    <div class="counter-one__count-box">
                        <h3 class="odometer" data-count="48">00</h3>
                        <span class="counter-one__letter">k</span>
                    </div>
                    <p class="counter-one__text">Projects funded</p>
                </li>
                <li class="counter-one__single">
                    <div class="counter-one__count-box">
                        <h3 class="odometer" data-count="38">00</h3>
                        <span class="counter-one__letter">%</span>
                    </div>
                    <p class="counter-one__text">Kids need help</p>
                </li>
                <li class="counter-one__single">
                    <div class="counter-one__count-box">
                        <h3 class="odometer" data-count="230">00</h3>
                        <span class="counter-one__letter"></span>
                    </div>
                    <p class="counter-one__text">Our volunteers</p>
                </li>
            </ul>
        </div>
    </div>
</section> -->

<!-- <section class="events-one">
    <div class="events-one-shape-1" style="background-image: url(<?php echo e(asset('site/assets/images/shapes/events-one-shape-1.png')); ?>)">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-lg-4">
                <div class="events-one__left">
                    <div class="section-title text-left">
                        <span class="section-title__tagline">Upcoming events</span>
                        <h2 class="section-title__title">Latest upcoming events or welfare programs</h2>
                    </div>
                    
                    <a href="" class="thm-btn events-one__btn">Discover More</a>
                </div>
            </div>
            <div class="col-xl-8 col-lg-8">
                <div class="events-one__right">
                    <div class="events-one__carousel owl-carousel owl-theme thm-owl__carousel" data-owl-options='{
                        "loop": true,
                        "autoplay": true,
                        "margin": 20,
                        "nav": true,
                        "dots": false,
                        "smartSpeed": 500,
                        "autoplayTimeout": 10000,
                        "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-right-arrow\"></span>"],
                        "responsive": {
                            "0": {
                                "items": 1
                            },
                            "768": {
                                "items": 2
                            },
                            "992": {
                                "items": 2
                            },
                            "1200": {
                                "items": 3
                            }
                        }
                    }'>
                        <div class="item">
                            <div class="events-one__single">
                                <div class="events-one__img">
                                    <img src="<?php echo e(asset('site/assets/images/events/events-1-1.jpg')); ?>" alt="">
                                    <div class="events-one__date">
                                        <p>23 July, 2022</p>
                                    </div>
                                    <div class="events-one__content">
                                        <ul class="list-unstyled events-one__meta">
                                           <li>Lions Club of Pokhara Metro City</li>
                                        </ul>
                                        <h3 class="events-one__title"><a href="">Play for the
                                                world
                                                with us</a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="events-one__single">
                                <div class="events-one__img">
                                    <img src="<?php echo e(asset('site/assets/images/events/events-1-2.jpg')); ?>" alt="">
                                    <div class="events-one__date">
                                        <p>23 July, 2022</p>
                                    </div>
                                    <div class="events-one__content">
                                        <ul class="list-unstyled events-one__meta">
                                            <li><li>Lions Club of Annapurna Pokhara</li></li>
                                        </ul>
                                        <h3 class="events-one__title"><a href="">Contrary to
                                                popular belief</a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="events-one__single">
                                <div class="events-one__img">
                                    <img src="<?php echo e(asset('site/assets/images/events/events-1-3.jpg')); ?>" alt="">
                                    <div class="events-one__date">
                                        <p>23 May, 2022</p>
                                    </div>
                                    <div class="events-one__content">
                                        <ul class="list-unstyled events-one__meta">
                                            <li><li>Lions Club of Annapurna Pokhara</li></li>
                                        </ul>
                                        <h3 class="events-one__title"><a href="">There are
                                                many variations of</a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="events-one__single">
                                <div class="events-one__img">
                                    <img src="<?php echo e(asset('site/assets/images/events/events-1-1.jpg')); ?>" alt="">
                                    <div class="events-one__date">
                                        <p>23 July, 2022</p>
                                    </div>
                                    <div class="events-one__content">
                                        <ul class="list-unstyled events-one__meta">
                                            <li><li>Lions Club of Annapurna Pokhara</li></li>
                                        </ul>
                                        <h3 class="events-one__title"><a href="">Play for the
                                                world
                                                with us</a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="events-one__single">
                                <div class="events-one__img">
                                    <img src="<?php echo e(asset('site/assets/images/events/events-1-2.jpg')); ?>" alt="">
                                    <div class="events-one__date">
                                        <p>23 July, 2022</p>
                                    </div>
                                    <div class="events-one__content">
                                        <ul class="list-unstyled events-one__meta">
                                            <li><li>Lions Club of Annapurna Pokhara</li></li>
                                        </ul>
                                        <h3 class="events-one__title"><a href="">Contrary to
                                                popular belief</a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="events-one__single">
                                <div class="events-one__img">
                                    <img src="<?php echo e(asset('site/assets/images/events/events-1-3.jpg')); ?>" alt="">
                                    <div class="events-one__date">
                                        <p>23 July, 2022</p>
                                    </div>
                                    <div class="events-one__content">
                                        <ul class="list-unstyled events-one__meta">
                                            <li><li>Lions Club of Annapurna Pokhara</li></li>
                                        </ul>
                                        <h3 class="events-one__title"><a href="">There are
                                                many variations of</a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->

<!-- <section class="news-one">
    <div class="container">
        <div class="section-title text-center">
            <span class="section-title__tagline">News & articles</span>
            <h2 class="section-title__title">latest news <br> and articles
            </h2>
        </div>
        <div class="row">
            <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                <div class="news-one__single">
                    <div class="news-one__img">
                        <img src="<?php echo e(asset('site/assets/images/blog/news-1-1.jpg')); ?>" alt="">
                    </div>
                    <div class="news-one__content-box">
                        <div class="news-one__content-inner">
                            <div class="news-one__content">
                                <ul class="list-unstyled news-one__meta">
                                    <li><a href=""><i class="far fa-user-circle"></i> Admin</a>
                                    </li>
                                </ul>
                                <h3 class="news-one__title"><a href="">How does the
                                        malnutrition
                                        affect children?</a></h3>
                            </div>
                            <div class="news-one__bottom">
                                <div class="news-one__read-more">
                                    <a href=""> <span class="icon-right-arrow"></span> Read
                                        More</a>
                                </div>
                                <div class="news-one__share">
                                    <a href="#"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                            <div class="news-one__social-box">
                                <ul class="list-unstyled news-one__social">
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="news-one__date">
                            <p>23 May, 2022</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                <div class="news-one__single">
                    <div class="news-one__img">
                        <img src="<?php echo e(asset('site/assets/images/blog/news-1-2.jpg')); ?>" alt="">
                    </div>
                    <div class="news-one__content-box">
                        <div class="news-one__content-inner">
                            <div class="news-one__content">
                                <ul class="list-unstyled news-one__meta">
                                    <li><a href=""><i class="far fa-user-circle"></i> Club Name</a>
                                    </li>
                                    
                                </ul>
                                <h3 class="news-one__title"><a href="">Lorem Ipsum has been the
                                        industry's standard</a></h3>
                            </div>
                            <div class="news-one__bottom">
                                <div class="news-one__read-more">
                                    <a href=""> <span class="icon-right-arrow"></span> Read
                                        More</a>
                                </div>
                                <div class="news-one__share">
                                    <a href="#"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                            <div class="news-one__social-box">
                                <ul class="list-unstyled news-one__social">
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="news-one__date">
                            <p>23 May, 2022</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                <div class="news-one__single">
                    <div class="news-one__img">
                        <img src="<?php echo e(asset('site/assets/images/blog/news-1-3.jpg')); ?>" alt="">
                    </div>
                    <div class="news-one__content-box">
                        <div class="news-one__content-inner">
                            <div class="news-one__content">
                                <ul class="list-unstyled news-one__meta">
                                    <li><a href=""><i class="far fa-user-circle"></i> Admin</a>
                                    </li>
                                    
                                </ul>
                                <h3 class="news-one__title"><a href="">There are many
                                        variations of passages of Lorem</a></h3>
                            </div>
                            <div class="news-one__bottom">
                                <div class="news-one__read-more">
                                    <a href=""> <span class="icon-right-arrow"></span> Read
                                        More</a>
                                </div>
                                <div class="news-one__share">
                                    <a href="#"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                            <div class="news-one__social-box">
                                <ul class="list-unstyled news-one__social">
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="news-one__date">
                            <p>23 May, 2022</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('site/assets/js/plug_accordion.js')); ?>"></script>
<script src="<?php echo e(asset('site/assets/js/marquee.js')); ?>"></script>
<script>
	$(document).ready(function() 
	{
		$("#slides").msAccordion({defaultid:1, autodelay:4});
		var options = {
		newsList: "#headlines",
		startDelay: 2,
		placeHolder1: "_",
		stopOnHover: false,
		controls: false,
		}
		$().newsTicker(options);
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lionj/resources/views/site/home.blade.php ENDPATH**/ ?>