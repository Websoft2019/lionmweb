<?php $__env->startSection('content'); ?>
<section class="page-header">
    <div class="page-header-bg" style="background-image: url(assets/images/backgrounds/page-header-bg.jpg)">
    </div>
    <div class="container">
        <div class="page-header__inner">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="<?php echo e(route('getHome')); ?>">Home</a></li>
                <li><span>/</span></li>
                <li class="active">News &amp; Events</li>
            </ul>
            <h2>News &amp; Events</h2>
        </div>
    </div>
</section>
<section class="news-details">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12">
                <div class="news-details__left">
                    <div class="news-details__content">
                        <?php if($news->count()): ?>
                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        
                                            <?php if($new->photo): ?>
                                            <div class="news-details__img">
                                                <img src="<?php echo e(asset('site/uploads/news/'.$new->photo)); ?>" alt="">
                                            </div>
                                            <?php else: ?>
                                            <div class="news-details__img1" style="text-align: center;">
                                            <img src="<?php echo e(asset('admin/assets/img/default_logo.jpg')); ?>" alt="" width="200">
                                            </div>
                                            <?php endif; ?>
                                        
                                    </div>
                                    <div class="col-md-8">
                                        <h3 class="news-details__title"><?php echo e($new->title); ?></h3>
                                        <hr style="margin: 0;">
                                        <p style="text-align: right;"> <small><strong>Posted By : </strong> District Office , <strong>Published Date : </strong> <?php echo e($new->created_at->format('d M, Y')); ?></small></p>
                                        <hr style="margin: 0;">
                                        <p class="news-details__text-1" style="margin-top: 10px;">
                                            <?php echo $new->detail; ?>

                                        </p>
                                        <p style="text-align: right;">
                                            <a href="<?php echo e(route('getNewsDetail', $new->slug)); ?>" class="btn btn-primary">Read More</a>
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="row">
                            <div class="col-md-12">
                                No any news upload yet.
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lionsclu/resources/views/site/news.blade.php ENDPATH**/ ?>