<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card my-4">
        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
          <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
            <div class="row">
                <div class="col-6">
                    <h6 class="text-white text-capitalize ps-3">List of Registration</h6>
                </div>
                <div class="col-6" style="text-align:right;">
                    <a class="btn btn-primary" href="<?php echo e(route('admin.getManageRegistration')); ?>">Create New Registration</a>
                </div>
            </div>
          </div>
        </div>
        <div class="card-body px-0 pb-2">
            <div class="row">
                <div class="col-md-12" style="padding: 40px;">
                    <?php if(session('message')): ?>
                    <div class="alert alert-primary alert-dismissible text-white" role="alert">
                        <span class="text-sm"><?php echo e(session('message')); ?></span>
                        <button type="button" class="btn-close text-lg py-3 opacity-10" data-bs-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">×</span>
                        </button>
                      </div>
                    <?php endif; ?>
                    
                        <div class="modal-body">
                            <div class="row">
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php
                                    $noofbooking = App\Models\EventRegisterMember::where('registration_id', $event->id)->where('payment_status', 'Y')->count();
                                  ?>
                                  <div class="col-lg-4 col-md-6 mt-4 mb-4">
                                    <div class="card z-index-2 ">
                                      <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
                                        <div class="bg-gradient-primary shadow-primary border-radius-lg py-3 pe-1">
                                          <div class="chart" style="text-align: center;">
                                            <a href="<?php echo e(route('admin.getRegstrationDetail', $event->id)); ?>"><h1 style="color: yellow;"><?php echo e($noofbooking); ?> <span style="font-size:13px;">/Booked</span></h1></a>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="card-body">
                                        <h6 class="mb-0" style="min-height:53px;"><?php echo e($event->title); ?> - <?php echo e($event->lion_year); ?></h6>
                                        <p class="text-sm "><?php echo e($event->vennue); ?> | <?php echo e($event->time); ?></p>
                                        <p class="text-sm ">Date : <?php echo e($event->date); ?> | Club Registration Limit : <?php echo e($event->maxperson); ?></p>
                                        <p class="text-sm ">registration Deadline : <?php echo e($event->registration_stop); ?> | Registration Cost : Npr. <?php echo e($event->cost); ?>/- </p>
                                        <hr class="dark horizontal">
                                        <div class="d-flex ">
                                          
                                          <p class="mb-0 text-sm"> <a href="">Edit</a> | <a href="">Delete</a></p>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                 



                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                        </div>
                     
                    
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lionsclub/resources/views/admin/pages/registration/list.blade.php ENDPATH**/ ?>