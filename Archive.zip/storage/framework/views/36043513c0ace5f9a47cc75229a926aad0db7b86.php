<?php $__env->startSection('content'); ?>
<section class="page-header">
    <div class="page-header-bg" style="background-image: url(assets/images/backgrounds/page-header-bg.jpg)">
    </div>
    <div class="container">
        <div class="page-header__inner">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="<?php echo e(route('getHome')); ?>">Home</a></li>
                <li><span>/</span></li>
                <li class="active">Programme/Projects</li>
            </ul>
            <h2>Programme/Projects</h2>
        </div>
    </div>
</section>
<!--Page Header End-->

<!--About Four Start-->
<section class="about-four">
    <div class="container">
        <div class="row">
            <div class="row">
                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                    <div class="causes-one__single">
                        <div class="causes-one__img">
                            <img src="<?php echo e(asset('site/uploads/program/'.$program->photo)); ?>" alt="">
                            <div class="causes-one__cat">
                                <p>Focused Programs</p>
                            </div>
                        </div>
                        <div class="causes-one__content">
                            <h3 class="causes-one__title"><a href="<?php echo e(route('getProgramDetail', $program->slug)); ?>"><?php echo e($program->title); ?></a>
                            </h3>
                            <div class="col-md-12" style="text-align:center; margin-top: 10px;">
                                <a href="<?php echo e(route('getProgramDetail', $program->slug)); ?>" class="thm-btn">Read Detail</a>
                            </div>
                        </div>
                       
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lionm/resources/views/site/projects.blade.php ENDPATH**/ ?>