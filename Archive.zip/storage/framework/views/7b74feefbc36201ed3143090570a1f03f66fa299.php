<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<style>
    .form-group{
    padding-top:20px;
}
.form-group label{
    color: #033c8a;
}
.dataTables_wrapper{
    padding: 30px;
  } 

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12 col-sm-12 mb-xl-0 mb-4">
      <div class="card">
        <div class="card-header p-3 pt-2">
          <div class="icon icon-lg icon-shape bg-gradient-dark shadow-dark text-center border-radius-xl mt-n4 position-absolute">
            <i class="material-icons opacity-10">weekend</i>
          </div>
          <div class="text-end pt-1">
            <p class="text-sm mb-0 text-capitalize"><?php echo e($club->club_membership_id); ?></p>
            <h4 class="mb-0"><?php echo e($club->name); ?></h4>
          </div>
        </div>
        <hr class="dark horizontal my-0">
        <div class="card-footer p-3">
          <div class="row">
            <div class="col-md-6">
              <?php $designation= App\Models\Officer::where('id', $club->contact_person_designation)->limit(1)->first(); ?>
              <p class="mb-0"><span class="text-success text-sm font-weight-bolder">Club Contact Person : <?php echo e($club->contact_person); ?> (<?php echo e($designation->title); ?>) </span><small style="display:block;"><?php echo e($club->contact_number); ?></small></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    
  </div>
  <br />
  <div class="row">
    <div class="col-xl-4 col-sm-6 mb-xl-0 mb-4">
        <div class="card">
          <div class="card-header p-3 pt-2">
            <div class="icon icon-lg icon-shape bg-gradient-success shadow-success text-center border-radius-xl mt-n4 position-absolute">
              <i class="material-icons opacity-10">person</i>
            </div>
            <div class="text-end pt-1">
              <p class="text-sm mb-0 text-capitalize">Total Members</p>
              <h4 class="mb-0"><?php echo e($members->count()); ?></h4>
            </div>
          </div>
          <hr class="dark horizontal my-0">
          <div class="card-footer p-3">
            <p class="mb-0"><span class="text-danger text-sm font-weight-bolder"></span>Lion Year <?php echo e(env('lion_year')); ?></p>
          </div>
        </div>
      </div>
      <div class="col-xl-4 col-sm-6">
        <div class="card">
          <div class="card-header p-3 pt-2">
            <div class="icon icon-lg icon-shape bg-gradient-info shadow-info text-center border-radius-xl mt-n4 position-absolute">
              <i class="material-icons opacity-10">weekend</i>
            </div>
            <div class="text-end pt-1">
              <p class="text-sm mb-0 text-capitalize">Total Program</p>
              <h4 class="mb-0">0</h4>
            </div>
          </div>
          <hr class="dark horizontal my-0">
          <div class="card-footer p-3">
            <p class="mb-0"><span class="text-success text-sm font-weight-bolder">0 </span>this month</p>
          </div>
        </div>
      </div>
      <div class="col-xl-4 col-sm-6 mb-xl-0 mb-4">
        <div class="card">
          <div class="card-header p-3 pt-2">
            <div class="icon icon-lg icon-shape bg-gradient-success shadow-success text-center border-radius-xl mt-n4 position-absolute">
              <i class="material-icons opacity-10">person</i>
            </div>
            <div class="text-end pt-1">
              <p class="text-sm mb-0 text-capitalize">Club Donation</p>
              <?php $__currentLoopData = $donationtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donnertype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $countdonner = App\Models\Donor::where('club_id', $club->id)->where('donor_type_id', $donnertype->id)->count(); ?>
              <?php echo e($donnertype->title); ?> - <?php echo e($countdonner); ?>|
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
          </div>
          <hr class="dark horizontal my-0">
          <div class="card-footer p-3">
            <p class="mb-0"><span class="text-danger text-sm font-weight-bolder"></span>&nbsp; &nbsp;  &nbsp; </p>
          </div>
        </div>
      </div>
  </div>
 <br />
  <div class="row mb-4">
    <div class="col-lg-12 col-md-6">
      <div class="card">
        <div class="card-header pb-0">
          <div class="row">
            <div class="col-lg-6 col-7">
              <h6>Club Members</h6>
              <p class="text-sm mb-0">
                <i class="fa fa-check text-info" aria-hidden="true"></i>
                <span class="font-weight-bold ms-1"><?php echo e($members->count()); ?></span> Total Members
                <?php $__errorArgs = ['member_membership_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                dfkjasdf
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </p>
            </div>
            <div class="col-md-6" style="text-align: right;">
              <a data-bs-toggle="modal" data-bs-target="#AddNewMemberModal" class="btn btn-primary">Add Member</a>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card-body px-0 pb-2">
              <div class="table-responsive">
                <?php if(session('message')): ?>
                <div class="row">
                  <div class="col-md-12" style="padding: 0 40px;">
                    <div class="alert alert-success alert-dismissible text-white" role="alert">
                      <span class="text-sm"><?php echo e(session('message')); ?></span>
                      <button type="button" class="btn-close text-lg py-3 opacity-10" data-bs-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  </div>
                </div>
                <?php endif; ?>
                <table class="table align-items-center mb-0" id="myTable">
                  <thead>
                    <tr>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Membership ID</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Degination</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Contact Number</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Status</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"></th>
                    </tr>
                  </thead>
                  <tbody id="tablecontents">
                    <?php if($members->count()): ?>
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($member->status == 'Drop'): ?>
                    <tr class="row1" data-id="<?php echo e($member->id); ?>" style="color: #ccc;">
                    <?php else: ?>
                    <tr class="row1" data-id="<?php echo e($member->id); ?>">
                    <?php endif; ?>
                      <td>
                        <div class="d-flex px-2 py-1">
                          <div>
                            <?php if($member->photo): ?>
                              <img src="<?php echo e(asset('site/uploads/members/'.$member->photo)); ?>" class="avatar avatar-sm me-3" alt="xd">
                            <?php else: ?>
                              <img src="<?php echo e(asset('site/assets/images/logo.png')); ?>" class="avatar avatar-sm me-3" alt="xd">
                            <?php endif; ?>
                          </div>
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="mb-0 text-sm"><?php echo e($member->name); ?> - <?php echo e($member->id); ?></h6>
                            <small>Membersip ID : <?php echo e($member->member_membership_no); ?></small>
                          </div>
                        </div>
                      </td>
                      <td>
                        <?php
                          $memberDsearch = App\Models\Member_Designation_Enroll::where('member_id',$member->id )->limit(1)->first();
                          $Dmember = App\Models\Officer::where('id', $memberDsearch->designation_id)->limit(1)->first();
                        ?>
                        <?php echo e($Dmember->title); ?>

                      </td>
                      <td class="align-middle text-center text-sm">
                        <span class="text-xs font-weight-bold"><?php echo e($member->personal_contact_number); ?></span>
                      </td>
                      <td class="align-middle">
                        <?php if($member->status == 'Active'): ?>
                          Active
                        <?php elseif($member->status == 'Drop'): ?>
                          Drop
                        <?php else: ?>
                          Deleted
                        <?php endif; ?>
                      </td>
                      <td class="align-middle">
                        <a href="<?php echo e(route('admin.getMemberDetail', $member->id)); ?>">View Detail</a>
                      </td>
                    </tr>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <tr>
                        <td colspan="4" class="text-center">No Members upload yet!!!</td>
                      </tr>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row mt-4">
    <div class="col-lg-4 col-md-6 mt-4 mb-4">
      <div class="card z-index-2 ">
        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
          <div class="bg-gradient-primary shadow-primary border-radius-lg py-3 pe-1">
            <div class="chart">
              <canvas id="chart-bars" class="chart-canvas" height="170"></canvas>
            </div>
          </div>
        </div>
        <div class="card-body">
          <h6 class="mb-0 ">Website Views</h6>
          <p class="text-sm ">Last Campaign Performance</p>
          <hr class="dark horizontal">
          <div class="d-flex ">
            <i class="material-icons text-sm my-auto me-1">schedule</i>
            <p class="mb-0 text-sm"> campaign sent 2 days ago </p>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-6 mt-4 mb-4">
      <div class="card z-index-2  ">
        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
          <div class="bg-gradient-success shadow-success border-radius-lg py-3 pe-1">
            <div class="chart">
              <canvas id="chart-line" class="chart-canvas" height="170"></canvas>
            </div>
          </div>
        </div>
        <div class="card-body">
          <h6 class="mb-0 "> Daily Sales </h6>
          <p class="text-sm "> (<span class="font-weight-bolder">+15%</span>) increase in today sales. </p>
          <hr class="dark horizontal">
          <div class="d-flex ">
            <i class="material-icons text-sm my-auto me-1">schedule</i>
            <p class="mb-0 text-sm"> updated 4 min ago </p>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-4 mt-4 mb-3">
      <div class="card z-index-2 ">
        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
          <div class="bg-gradient-dark shadow-dark border-radius-lg py-3 pe-1">
            <div class="chart">
              <canvas id="chart-line-tasks" class="chart-canvas" height="170"></canvas>
            </div>
          </div>
        </div>
        <div class="card-body">
          <h6 class="mb-0 ">Completed Tasks</h6>
          <p class="text-sm ">Last Campaign Performance</p>
          <hr class="dark horizontal">
          <div class="d-flex ">
            <i class="material-icons text-sm my-auto me-1">schedule</i>
            <p class="mb-0 text-sm">just updated</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="modal fade" id="AddNewMemberModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add New Member</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?php echo e(route('admin.postAddNewMember', $club->slug)); ?>" method="POST" enctype="multipart/form-data">
          <input type="hidden" name="club_id" value="<?php echo e($club->id); ?>">
          <input type="hidden" name="club_slug" value="<?php echo e($club->slug); ?>">
          <?php echo csrf_field(); ?>
          <div class="modal-body">
                  <div class="row mb-4">
                    <div class="col-md-12">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline <?php if(old('photo') != ''): ?> focused is-focused <?php endif; ?>">
                            <label class="form-label">Photo </label>
                            <input type="file" name="photo" class="form-control  <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('photo')); ?>">
                            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
              <div class="row mb-4">
                <div class="col-md-6">
                  <div class="form-group">
                      <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline <?php if(old('fname') != ''): ?> focused is-focused <?php endif; ?>">
                            <label class="form-label">Full Name *</label>
                            <input type="text" name="fname" class="form-control  <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('fname')); ?>" required>
                            
                              <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($message); ?></strong>
                                  </span>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                      </div>
                      <div>
                        <input type="checkbox" name="charter_member"> Charter Member?
                        <input type="checkbox" name="charter_president"> Charter President?
                      </div>
                  </div>
              </div>
                  <div class="col-md-3">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline <?php if(old('member_membership_no') != ''): ?> focused is-focused <?php endif; ?>">
                            <label class="form-label">Membership No * </label>
                            <input type="text" class="form-control" name="member_membership_no" value="<?php echo e(old('member_membership_no')); ?>">
                            <?php $__errorArgs = ['member_membership_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                        </div>
                      </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                      <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                        <div class="input-group input-group-outline focused is-focused">
                          <label class="form-label">Cub Designation * </label>
                          <select class="form-control" name="designation_id" required>
                            <?php $__currentLoopData = $officers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($officer->id); ?>" ><?php echo e($officer->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
              <div class="row mb-4">
                  <div class="col-md-6">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline <?php if(old('email') != ''): ?> focused is-focused <?php endif; ?>">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                          </div>
                        </div>
                      </div>
                  </div>
                  <div class="col-md-3">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline focused is-focused">
                            <label class="form-label">Gender *</label>
                            <select class="form-control" name="gender" required>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                            </select>
                          </div>
                        </div>
                      </div>
                  </div> 
                  <div class="col-md-3">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline focused is-focused">
                            <label class="form-label">Date Of Birth</label>
                            <input type="date" class="form-control" name="dob" value="<?php echo e(old('dob')); ?>">
                          </div>
                        </div>
                      </div>
                  </div>
              </div>
              <div class="row mb-4"> 
                  <div class="col-md-3">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline <?php if(old('sponsor_name') != ''): ?> focused is-focused <?php endif; ?>">
                            <label class="form-label">Sponsor Name</label>
                            <input type="text" class="form-control" name="sponsor_name" value="<?php echo e(old('sponsor_name')); ?>">
                          </div>
                        </div>
                      </div>
                  </div>
                  <div class="col-md-3">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline <?php if(old('mobile_number') != ''): ?> focused is-focused <?php endif; ?>">
                            <label class="form-label">Personal Phone</label>
                            <input type="number" class="form-control" name="mobile_number" value="<?php echo e(old('mobile_number')); ?>">
                          </div>
                        </div>
                      </div>
                  </div>
                  <div class="col-md-3">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline <?php if(old('office_number') != ''): ?> focused is-focused <?php endif; ?>">
                            <label class="form-label">Office Phone</label>
                            <input type="number" class="form-control" name="office_number" value="<?php echo e(old('office_number')); ?>">
                          </div>
                        </div>
                      </div>
                  </div>
                  <div class="col-md-3">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline <?php if(old('home_number') != ''): ?> focused is-focused <?php endif; ?>">
                            <label class="form-label">Home Phone</label>
                            <input type="number" class="form-control" name="home_number" value="<?php echo e(old('home_number')); ?>">
                          </div>
                        </div>
                      </div>
                  </div>
              </div>
              <div class="row mb-4">
                  <div class="col-md-5">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline <?php if(old('address') != ''): ?> focused is-focused <?php endif; ?>">
                            <label class="form-label">Address</label>
                            <input type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>">
                          </div>
                        </div>
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline <?php if(old('spouse_name') != ''): ?> focused is-focused <?php endif; ?>">
                            <label class="form-label">Spouse/Companion Name</label>
                            <input type="text" class="form-control" name="spouse_name" value="<?php echo e(old('spouse_name')); ?>">
                          </div>
                        </div>
                      </div>
                  </div>
                  <div class="col-md-3">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline focused is-focused">
                            <label class="form-label">Occupation <small style="color:red;">*</small></label>
                            <select class="form-control" name="occupation_id" required>
                                <?php $__currentLoopData = $occupations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occupation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($occupation->id); ?>"><?php echo e($occupation->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                        </div>
                      </div>
                  </div> 
              </div>
              <div class="row mb-4">
                  <div class="col-md-4">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline focused is-focused">
                            <label class="form-label">Club Join Date</label>
                            <input type="date" class="form-control" name="club_join_date" value="<?php echo e(old('club_join_date')); ?>">
                          </div>
                        </div>
                      </div>
                  </div>
                 
                  <div class="col-md-4">
                      <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                          <div class="input-group input-group-outline <?php if(old('blood_group') != ''): ?> focused is-focused <?php endif; ?>">
                            <label class="form-label">Blood Group</label>
                            <input type="text" class="form-control" name="blood_group" value="<?php echo e(old('blood_group')); ?>">
                          </div>
                        </div>
                      </div>
                  </div>
              </div>
             
          
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add Member</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
  
  
    <?php $__env->startSection('js'); ?>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>
    <script>
      $(document).ready( function () {
        $('#myTable').DataTable();
    });
    </script>
    <script type="text/javascript">
      $(function () {
        $( "#tablecontents" ).sortable({
          items: "tr",
          cursor: 'move',
          opacity: 0.6,
          update: function(e) {
              updatePostOrder();
          }
        });

        function updatePostOrder() {
          var level = [];
          
          $('tr.row1').each(function(index, element) {
            level.push({
              id: $(this).attr('data-id'),
              level: index
            });
          });

          $.ajax({
            type: "POST",
            dataType: "json",
            url: "<?php echo e(url('admin/sort/members')); ?>",
            data: {
              level: level,
              "_token": "<?php echo e(csrf_token()); ?>",
            },
            success: function(response) {
                if (response.status == "success") {
                  console.log(response);
                } else {
                  console.log(response);
                }
            }
          });
        }
      });
    </script>
    <?php $__errorArgs = ['member_membership_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <script>
        $(document).ready(function(){
            
            $('#AddNewMemberModal').modal('show');
        });
      </script>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  <?php $__env->stopSection(); ?>


  
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lionj/resources/views/admin/pages/club/detail.blade.php ENDPATH**/ ?>