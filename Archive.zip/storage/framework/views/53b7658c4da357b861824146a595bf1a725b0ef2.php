<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<style>
  .dataTables_wrapper{
    padding: 30px;
  }
</style>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card my-4">
        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
          <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
            <div class="row">
                <div class="col-6">
                    <h6 class="text-white text-capitalize ps-3">District Team</h6>
                </div>
                <div class="col-6" style="text-align:right;">
                    <a class="btn btn-primary" href="<?php echo e(route('admin.getAddDistrictTeam')); ?>">Add New Team</a>
                </div>
                
            </div>
          </div>
        </div>
        <div class="card-body px-0 pb-2">
          <div class="table-responsive p-0">
            <?php if(session('message')): ?>
            <div class="row">
              <div class="col-md-12" style="padding: 0 40px;">
                <div class="alert alert-success alert-dismissible text-white" role="alert">
                  <span class="text-sm"><?php echo e(session('message')); ?></span>
                  <button type="button" class="btn-close text-lg py-3 opacity-10" data-bs-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                  </button>
                </div>
              </div>
            </div>
            <?php endif; ?>
            <table class="table align-items-center mb-0" id="myTable">
              <thead>
                <tr>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"></th>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Department</th>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Desigination</th>

                  <th class="text-secondary opacity-7"></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $districtofficers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $districtofficer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $member = App\Models\Member::where('member_membership_no', $districtofficer->club_member_id)->limit(1)->first();
                    $department = App\Models\Department::where('id', $districtofficer->department_id)->limit(1)->first();
                    $designation = App\Models\Officer::where('id', $districtofficer->designation_id)->limit(1)->first();
                ?>
                <tr>
                  <td>
                    <div class="d-flex px-2 py-1">

                      <img src="<?php echo e(asset('admin/assets/img/default_logo.jpg')); ?>" class="avatar avatar-sm me-3 border-radius-lg" alt="user1">
                     
                      <div class="d-flex flex-column justify-content-center">
                        <h6 class="mb-0 text-sm"><?php echo e($member->name); ?></h6>
                        <p class="text-xs text-secondary mb-0">Member ID : <?php echo e($member->club_membership_id); ?></p>
                      </div>
                    </div>
                  </td>
                  <td>
                    <p class="text-xs font-weight-bold mb-0"><?php echo e($department->title); ?></p>
                   
                    <p class="text-xs text-secondary mb-0"><?php echo e($districtofficer->lion_year); ?></p>
                  </td>
                  <td class="align-middle text-center text-sm">
                    <?php echo e($designation->title); ?>

                  </td>
                  <td class="align-middle">
                    <a href="" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit Club">
                      Edit</a>
                      |
                    <a href="" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Delete Club" onclick="return confirm('Club not deleted permanently, its hide from system.')">
                      Delete
                    </a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script>
  $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lionm/resources/views/admin/pages/districtofficer/manage.blade.php ENDPATH**/ ?>