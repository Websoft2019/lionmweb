<?php $__env->startSection('content'); ?>
<section class="page-header">
    <div class="page-header-bg" style="background-image: url(assets/images/backgrounds/page-header-bg.jpg)">
    </div>
    <div class="container">
        <div class="page-header__inner">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="<?php echo e(route('getHome')); ?>">Home</a></li>
                <li><span>/</span></li>
                <li><a href="">Notice</a></li>
                <li class="active"><?php echo e($notice->title); ?></li>
            </ul>
            <h2>Notice</h2>
        </div>
    </div>
</section>
<section class="news-details">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-7">
                <div class="news-details__left">
                    <div class="news-details__content">

                        <h3 class="news-details__title"><?php echo e($notice->title); ?></h3>
                        <p class="news-details__text-1">
                            <?php echo $notice->detail; ?>

                        </p>
                        <?php if($notice->photo): ?>
                        <hr>
                        <p><a href="<?php echo e(asset('site/uploads/notice/'.$notice->photo)); ?>">View/Download</a></p>
                        <hr>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-5">
                <div class="sidebar">
                    <div class="sidebar__single sidebar__search">
                        <form action="#" class="sidebar__search-form">
                            <input type="search" placeholder="Search here">
                            <button type="submit"><i class="icon-magnifying-glass"></i></button>
                        </form>
                    </div>
                    <div class="sidebar__single sidebar__category">
                        <div class="sidebar-shape-1"
                            style="background-image: url(assets/images/shapes/sidebar-shape-1.png);"></div>
                        <h3 class="sidebar__title">Other Notices</h3>
                        <ul class="sidebar__category-list list-unstyled">
                            <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('getNoticeDetail', $item->id)); ?>"><?php echo e($item->title); ?> <span class="icon-right-arrow"></span></a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home6/lionsclu/resources/views/site/noticedetail.blade.php ENDPATH**/ ?>