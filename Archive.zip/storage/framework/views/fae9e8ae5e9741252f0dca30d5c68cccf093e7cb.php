<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<style>
  .dataTables_wrapper{
    padding: 30px;
  }
</style>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card my-4">
        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
          <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
            <div class="row">
                <div class="col-6">
                    <h6 class="text-white text-capitalize ps-3">District Edit - <?php echo e(env('lion_year')); ?></h6>
                </div>
                <div class="col-6" style="text-align:right;">
                    <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#AddNewDepartment">Back to Department</a>
                </div>
                
            </div>
          </div>
        </div>
        <div class="card-body px-0 pb-2">
          <div class="table-responsive p-0">
            <?php if(session('message')): ?>
            <div class="row">
              <div class="col-md-12" style="padding: 0 40px;">
                <div class="alert alert-success alert-dismissible text-white" role="alert">
                  <span class="text-sm"><?php echo e(session('message')); ?></span>
                  <button type="button" class="btn-close text-lg py-3 opacity-10" data-bs-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                  </button>
                </div>
              </div>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('admin.postEditDepartment', $department->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row" style="margin-bottom:10px;">
                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                                    <div class="input-group input-group-outline">
                                      <label for="">Department Name &nbsp;</label>
                                      <input class="form-control" type="text" name="department" value="<?php echo e($department->title); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div>
                              &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                              <input type="checkbox" name="region" value="Y" <?php if($department->region == 'Y'){ echo 'checked'; } ?>> Region?
                              <input type="checkbox" name="zone" value="Y" <?php if($department->zone == 'Y'){ echo 'checked'; } ?>> Zone?
                            </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                              <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                                  <div class="input-group input-group-outline">
                                    <input class="form-control" type="text" value="<?php echo e($department->lion_year); ?>" disabled>
                                  </div>
                              </div>
                          </div>
                      </div>
                    </div>
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary">Edit Department</button>
                </div>
              </form>
          </div>
        </div>
      </div>
    </div>
  </div>

 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script>
  $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lionsclub/resources/views/admin/pages/department/departmentedit.blade.php ENDPATH**/ ?>