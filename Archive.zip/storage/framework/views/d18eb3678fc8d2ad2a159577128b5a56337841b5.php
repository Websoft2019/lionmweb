<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card my-4">
        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
          <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
            <div class="row">
                <div class="col-6">
                    <h6 class="text-white text-capitalize ps-3">Registration</h6>
                </div>
                <div class="col-6" style="text-align:right;">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#AddNewClubModal"> New Registration</button>
                </div>
            </div>
          </div>
        </div>
        <div class="card-body px-0 pb-2">
          <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
              <thead>
                <tr>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Name</th>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Club Name</th>
                  <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Registered Date</th>
                  <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Cost</th>
                  <th class="text-secondary opacity-7"></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $registered_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $memberinfo = App\Models\Member::where('member_membership_no', $item->member_id)->limit(1)->first();
                        $clubinfo = App\Models\Club::find($item->club_id);
                    ?>
                <tr>
                  <td>
                    <div class="d-flex px-2 py-1">
                      <?php if($memberinfo->photo): ?>
                      <div>
                        <img src="<?php echo e(asset('site/uploads/members/'.$member->photo)); ?>" class="avatar avatar-sm me-3 border-radius-lg" alt="user1">
                      </div>
                      <?php else: ?>
                      <img src="<?php echo e(asset('admin/assets/img/default_logo.jpg')); ?>" class="avatar avatar-sm me-3 border-radius-lg" alt="user1">
                      <?php endif; ?>
                      <div class="d-flex flex-column justify-content-center">
                        <h6 class="mb-0 text-sm"><?php echo e($memberinfo->name); ?></h6>
                        <p class="text-xs text-secondary mb-0">Membership ID : <?php echo e($memberinfo->member_membership_no); ?> <br /> Registration Code : <?php echo e($item->hash); ?></p>
                      </div>
                    </div>
                  </td>
                  <td>
                    <p class="text-xs font-weight-bold mb-0">
                        <?php echo e($clubinfo->name); ?>

                    </p>
                  </td>
                  <td class="align-middle text-center text-sm">
                    <?php echo e($item->created_at->format('d M, Y')); ?>

                  </td>
                  <td class="align-middle text-center">
                    <span class="text-secondary text-xs font-weight-bold">
                    NPR <?php echo e($item->cost); ?>

                    <small style="display: block;"><?php echo e($item->payment_type); ?></small>
                    </span>
                  </td>
                  <td class="align-middle">
                    <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                      Edit
                    </a> |
                    <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                      Delete
                    </a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="modal fade" id="AddNewClubModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add Register</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?php echo e(route('admin.postAddNewDonor')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="modal-body">
              <div class="row" style="margin-bottom:10px;">
                  <div class="col-md-4">
                      <div class="form-group">
                          <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                              <div class="input-group input-group-outline focus is-focused is-filled">
                                <label class="form-label">Event or Program *</label>
                                <input type="text" class="form-control" value="<?php echo e($eventinfo->title); ?>" disabled>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="form-group">
                          <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                              <div class="input-group input-group-outline is-filled">
                                <label class="form-label">Membership ID *</label>
                                <input type="number" id="membershipid" name="membership_id" class="form-control" autofocus required>
                                <input type="hidden" name="clubid" id="clubID">
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                            <div class="input-group input-group-outline">
                              <button class="btn btn-primary" id="membersSearch">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
                  
              </div>
              <div class="row" style="margin-bottom:10px;">
                  <div class="col-md-3">
                    <span id="memberPhoto"></span>
                  </div>
                  <div class="col-md-8">
                    <span id="memberName"></span> <br />
                    <span id="homeClub"></span> <br />
                    <span id="clubDesignation"></span> <br />
                  </div>
              </div>
              
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="donorSubmitButton" disabled>Add Donor</button>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
  $(document).ready(function() {
      $("#membersSearch").click(function(e) { 
          e.preventDefault();
              let membershipid = $('#membershipid').val();
              $.ajax({
						url: "/admin/ajax/search/membership",
						type:"POST",
						data:{
								"_token": "<?php echo e(csrf_token()); ?>",
								membershipid:membershipid
							},
							success:function(response)
							{
                document.getElementById("memberName").innerHTML = 'Full Name : '+response.membername;
                document.getElementById("homeClub").innerHTML = 'Home Club : '+response.memberhomeclub;
                document.getElementById("clubDesignation").innerHTML = 'Designation : '+response.memberdesignation;
                document.getElementById("memberPhoto").innerHTML = response.memberphoto;
                document.getElementById("clubID").value = response.clubid;
                $("#donorSubmitButton").prop('disabled', false);
              
                
              }
            });
            
      });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lionsclub/resources/views/admin/pages/registration/bookingdetail.blade.php ENDPATH**/ ?>