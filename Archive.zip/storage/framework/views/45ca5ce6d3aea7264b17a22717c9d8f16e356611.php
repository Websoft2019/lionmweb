<?php $__env->startSection('css'); ?>
    <style>
        .profilebox{
            border: 1px solid #ccc;
            padding: 20px;
        }
        .information{
            margin-top: 30px;
        }
        ul.information-item{
            list-style: none;
        }
        .information-item b{
            margin-top: 40px;
            color: #023c8a;
        }
        ul.peronalinformation li{
            padding: 5px 0;
        }
        .actionbox {
            text-align: right;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="page-header">
    <div class="page-header-bg" style="background-image: url(assets/images/backgrounds/page-header-bg.jpg)">
    </div>
    <div class="container">
        <div class="page-header__inner">
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="<?php echo e(route('getHome')); ?>">Home</a></li>
                <li><span>/</span></li>
                <li><a href="<?php echo e(route('club.getRegistrationList')); ?>">Registration</a></li>
                <li><span>/</span></li>
                <li class="active"><?php echo e($registration->title); ?></li>
            </ul>
            <h2><?php echo e($registration->title); ?></h2>
        </div>
    </div>
</section>
<section class="about-four" style="padding:60px 0 0; margin-bottom: 60px;">
    <div class="container">
        <div class="profilebox">
            <form action="<?php echo e(route('club.postEventRegister')); ?>" method="POST" name="main">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="eventid" value="<?php echo e($registration->id); ?>">
                <div class="row">
                    <div class="col-md-9">
                        <h5>Tick mark the participate lion Member</h5>
                        <br />
                        <?php if($members->count()): ?>
                        <ul style="padding:0; margin:0; list-style-type: none; columns: 2; -webkit-columns: 2; -moz-columns: 2;">
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- check member already register -->
                                    <?php
                                        $check = App\Models\EventRegisterMember::where('member_id', $member->member_membership_no)->where('registration_id', $registration->id)->where('payment_status', 'Y')->get();
                                    ?>
                                <li style="line-height: 50px; padding-bottom: 20px; overflow:hidden; display:block; min-height:30px">
                                    <input type="checkbox" value="<?php echo e($member->member_membership_no); ?>" name="membercheckbox[]" class="membercheckbox" <?php if($check->count()): ?> disabled <?php endif; ?>>
                                    Lion <?php echo e($member->name); ?> (<?php echo e($member->member_membership_no); ?>)
                                    <?php
                                    $post = App\Models\Member_Designation_Enroll::where('member_id', $member->id)->where('lion_year', env('lion_year'))->limit(1)->first();
                                    $degination = App\Models\Officer::where('id', $post->designation_id)->limit(1)->first();
                                    ?>
                                    <small style="display: block; line-height:3px; color: blue;">&nbsp; &nbsp; &nbsp; <?php echo e($degination->title); ?> <?php if($check->count()): ?> <span style="color: red;">Registered</span> <?php endif; ?></small>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>
                        <?php else: ?>
                        <p>No any member upload, before register upload your club members.</p>
                        <?php endif; ?>
                       
                    </div>
                    <div class="col-md-3">
                            <div class="event-details1__right">
                                <div class="row"> 
                                    <h5>Participant </h5> 
                                    <p>
                                        <span id="countselectedmember"></span>/members <br />
                                        <h4>Total Registration Cost</h4>
                                        <h1>Npr.<span id="totacost">0.00</span></h1>
                                    </p>
                                    <div>
                                        <input type="submit" class="btn btn-primary" value="Confirm" <?php if($members->count()) {echo ''; } else{ echo 'disabled'; } ?>>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
    $('.membercheckbox').click(function() {
        var a = document.forms["main"];
        var cost = "<?php echo $registration->cost; ?>";
        var x =a.querySelectorAll('input[type="checkbox"]:checked');
        var totalcost =  x.length*cost;
        document.getElementById("countselectedmember").innerHTML = x.length+' lion members selected';
        document.getElementById("totacost").innerHTML = totalcost;

    })
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home6/lionsclu/resources/views/club/registration/form.blade.php ENDPATH**/ ?>